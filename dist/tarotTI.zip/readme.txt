This Tarot Reader was written by Tursi back in the early 90's to run on FlipSide BBS in Ottawa. (There was also a PC version but I don't think anyone ran it.)

Ported in 2024 to the newer GCC and running locally, reformatted all the text for 40 columns, otherwise it's as originally done.
