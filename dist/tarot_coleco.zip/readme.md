20240229

This program is offered for the TI-99/4A, ColecoVision and for MSDOS.

-TI-

Provided as a 512kb non-inverted cart. Just insert and follow the prompts.

-Coleco-

512kb Megacart. Insert and follow the prompts. You'll use the keypad to answer prompts. When asked for Y/N, '1' is Y and '0' is N.

-MSDOS-

To use this tarot reader, simply extract the files into the same directory, and type 'TAROT'.

Instructions are given in program.

11 Feb 97 - You may now specify a file to log your reading to. It's just as ugly as the output to the screen,
but it gives you a way to record your session. Thanks to Canis for suggesting it.

Note that there appears to be a bug with respect to running under DOSBOX, you may have to press CONTROL-Enter instead of just enter to enter lines. If the y/N prompt at the beginning never continues, try that.

It's shipped here for MSDOS, but it should build under anything that can read the K&R C syntax it's presented in. Building in a newer compiler will probably fix the above-mentioned DOSBOX incompatibility, too.

Source will be at https://github.com/tursilion/tarot
