This TI-99/4A version is based on the BBS port that I made for FlipSide BBS back in the early 90's. It's presented here as a 16k cartridge built with the modern GCC and libti99, running in 40 column text mode.

Although the makefile creates a 32k file, it only needs 16k so I just truncated the binary.

